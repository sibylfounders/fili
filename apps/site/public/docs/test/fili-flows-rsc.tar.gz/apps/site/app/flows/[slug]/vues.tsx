"use client";

/**
 * Tout le rendu de la page de flow vit ici, côté client.
 *
 * Pourquoi : `@fili/react` est un baril `"use client"`, et ses composants à namespace
 * (`Card.Root`, `Alert.Root`) ne se résolvent pas dans le manifeste client quand une page
 * SERVEUR les rend à travers l'objet. C'est la convention déjà en place dans le site —
 * `app/md/[slug]/` fait pareil : la page serveur lit le contenu, une vue cliente le rend.
 */

import { Alert, Card } from "@fili/react";
import type { Cas, Graphe } from "@/lib/flows";
import { Diagramme } from "./diagramme";

const Chapeau = ({ kicker, titre, lead }: { kicker: string; titre: string; lead?: string }) => (
  <header className="mb-xl max-w-[70ch]">
    <p className="m-0 font-label text-xs font-semibold uppercase tracking-wider text-text-muted">
      {kicker}
    </p>
    <h2 className="m-0 mt-1 text-h3 font-semibold text-text-primary">{titre}</h2>
    {lead ? <p className="mt-sm text-text-secondary">{lead}</p> : null}
  </header>
);

/* ── Les moments : le squelette, hors canevas ─────────────────────────── */
function Moments({ g }: { g: Graphe }) {
  if (!g.moments.length) return null;
  return (
    <section className="mb-xl">
      <Chapeau
        kicker="Le squelette"
        titre={`${g.moments.length} moments`}
        lead="Les moments viennent du § « Le squelette du parcours ». La fiche n’écrit pas quel moment porte quel état : ils sont donc montrés à côté de la trajectoire, pas dessus."
      />
      <div className="grid gap-md md:grid-cols-2 lg:grid-cols-4">
        {g.moments.map((m) => (
          <Card.Root key={m.id} mode="static">
            <Card.Body>
              <Card.Title className="text-sm">
                {m.index}. {m.titre}
              </Card.Title>
              {m.conditionnel ? (
                <Card.Description className="font-label text-xs uppercase tracking-wider text-text-muted">
                  conditionnel
                </Card.Description>
              ) : null}
              <Card.Description className="mt-sm">{m.texte}</Card.Description>
            </Card.Body>
          </Card.Root>
        ))}
      </div>
    </section>
  );
}

/* ── La couverture : ce que l'inventaire dit du parcours ──────────────── */
const ORDRE = [
  "Couvert",
  "Couvert partiellement",
  "Partiel",
  "En attente",
  "Non couvert",
  "Absent",
  "Hors périmètre",
];

function Couverture({ g }: { g: Graphe }) {
  if (!g.couverture.length) return null;
  const parStatut = new Map<string, Cas[]>();
  for (const c of g.couverture) {
    if (!parStatut.has(c.statut)) parStatut.set(c.statut, []);
    parStatut.get(c.statut)!.push(c);
  }
  const ouverts = g.couverture.filter((c) => c.statut !== "Couvert");

  return (
    <section className="mb-xl">
      <Chapeau
        kicker="Couverture"
        titre={`${g.couverture.length} cas d’usage inventoriés`}
        lead={`${g.resume.couvert} couverts. Le reste n’est pas un oubli : chaque ligne nomme son propriétaire.`}
      />
      <ul className="mb-lg flex list-none flex-wrap gap-md p-0">
        {ORDRE.filter((s) => parStatut.has(s)).map((s) => (
          <li key={s} className="text-sm text-text-secondary">
            <span className="font-label uppercase tracking-wider text-text-muted">{s}</span>{" "}
            <span className="font-mono text-text-primary">{parStatut.get(s)!.length}</span>
          </li>
        ))}
      </ul>
      {ouverts.length ? (
        <div className="grid gap-md md:grid-cols-2">
          {ouverts.map((c) => (
            <Card.Root key={`${c.famille}-${c.cas}`} mode="static" density="compact">
              <Card.Body>
                <Card.Title className="text-sm">{c.cas}</Card.Title>
                <Card.Description className="font-label text-xs uppercase tracking-wider text-text-muted">
                  {c.statut} · {c.famille}
                </Card.Description>
                {c.proprietaire ? (
                  <Card.Description className="mt-sm">{c.proprietaire}</Card.Description>
                ) : null}
              </Card.Body>
            </Card.Root>
          ))}
        </div>
      ) : null}
    </section>
  );
}

/* ── Ce que le flow délègue ───────────────────────────────────────────── */
function Frontieres({ g }: { g: Graphe }) {
  if (!g.frontieres.length) return null;
  const sien = g.frontieres.filter((f) => f.duFlow);
  const delegue = g.frontieres.filter((f) => !f.duFlow);
  return (
    <section className="mb-xl">
      <Chapeau
        kicker="Frontières d’autorité"
        titre={`${sien.length} domaines au flow, ${delegue.length} délégués`}
        lead="Un flow n’invente aucune règle de composant ou de pattern — il les séquence."
      />
      <div className="grid gap-md md:grid-cols-2">
        {g.frontieres.map((f) => (
          <Card.Root key={f.domaine} mode="static" density="compact">
            <Card.Body>
              <Card.Title className="text-sm">{f.domaine}</Card.Title>
              <Card.Description className="font-label text-xs uppercase tracking-wider text-text-muted">
                {f.duFlow ? "porté par le flow" : `délégué · ${f.proprietaire}`}
              </Card.Description>
            </Card.Body>
          </Card.Root>
        ))}
      </div>
    </section>
  );
}

/* ── La vue complète ──────────────────────────────────────────────────── */
export function VueFlow({ graphe: g }: { graphe: Graphe }) {
  const projetable = g.etats.length > 0 && g.transitions.length > 0;

  return (
    <main className="mx-auto max-w-[1200px] px-lg py-xl">
      <header className="mb-xl max-w-[70ch]">
        <p className="m-0 font-label text-xs font-semibold uppercase tracking-wider text-text-muted">
          Flow · projection
        </p>
        <h1 className="m-0 mt-1 text-h2 font-semibold text-text-primary">{g.flow}</h1>
        <p className="mt-sm text-text-secondary">
          Diagramme dérivé de <code className="font-mono text-sm">{g.source.fiche}</code> (v
          {g.version}, empreinte <code className="font-mono text-sm">{g.source.empreinte}</code>).
          Rien n’est saisi ici : régénérer avec{" "}
          <code className="font-mono text-sm">npm run flows</code>.
        </p>
      </header>

      {g.nonLu.length ? (
        <Alert.Root tone="warning" className="mb-xl">
          <Alert.Icon />
          <Alert.Content>
            <Alert.Title>La fiche n’a pas été lue en entier</Alert.Title>
            {/* La liste ne va pas dans Alert.Description : celle-ci rend un <p>. */}
            <ul className="mb-0 mt-sm">
              {g.nonLu.map((n) => (
                <li key={n}>{n}</li>
              ))}
            </ul>
          </Alert.Content>
        </Alert.Root>
      ) : null}

      <Moments g={g} />

      <section className="mb-xl">
        <Chapeau
          kicker="Machine à états"
          titre="La trajectoire du compte"
          lead="Les états et leurs conditions de sortie viennent du tableau des transitions de la fiche. Ce qui apparaît détaché, sous le parcours, l’est parce que la fiche ne dit pas où le rattacher."
        />
        {projetable ? (
          <Diagramme graphe={g} />
        ) : (
          <Alert.Root tone="info">
            <Alert.Icon />
            <Alert.Content>
              <Alert.Title>Pas de machine à états dans la fiche</Alert.Title>
              <Alert.Description>
                Il n’y a rien à projeter en graphe tant que le § « Machine à états du parcours »
                n’est pas écrit.
              </Alert.Description>
            </Alert.Content>
          </Alert.Root>
        )}
      </section>

      {g.aArbitrer.length ? (
        <section className="mb-xl">
          <Chapeau
            kicker="À arbitrer"
            titre={`${g.aArbitrer.length} rattachements que la fiche ne nomme pas`}
            lead="La projection ne comble aucun de ces trous. Chacun est une décision qui revient à la doctrine, pas à l’outil."
          />
          <div className="grid gap-md md:grid-cols-2">
            {g.aArbitrer.map((a) => (
              <Card.Root key={a} mode="static" density="compact">
                <Card.Body>
                  <Card.Description>{a}</Card.Description>
                </Card.Body>
              </Card.Root>
            ))}
          </div>
        </section>
      ) : null}

      <Couverture g={g} />
      <Frontieres g={g} />
    </main>
  );
}

/* ── L'index des flows ────────────────────────────────────────────────── */
export function ListeFlows({ graphes }: { graphes: Graphe[] }) {
  return (
    <main className="mx-auto max-w-[1200px] px-lg py-xl">
      <header className="mb-xl max-w-[70ch]">
        <p className="m-0 font-label text-xs font-semibold uppercase tracking-wider text-text-muted">
          Flows
        </p>
        <h1 className="m-0 mt-1 text-h2 font-semibold text-text-primary">
          Les parcours, vus comme des diagrammes
        </h1>
        <p className="mt-sm text-text-secondary">
          Chaque vue est une projection de sa fiche <code className="font-mono text-sm">-UX.md</code>
          , pas un dessin. Un parcours n’apparaît en graphe que si sa fiche porte une machine à
          états.
        </p>
      </header>

      <div className="grid gap-md md:grid-cols-2">
        {graphes.map((g) => (
          <Card.Root key={g.flow} mode="clickable">
            <Card.Body>
              <Card.Title className="text-sm">
                <Card.TitleLink href={`/flows/${g.flow}/`}>{g.flow}</Card.TitleLink>
              </Card.Title>
              <Card.Description className="font-label text-xs uppercase tracking-wider text-text-muted">
                v{g.version} ·{" "}
                {g.etats.length && g.transitions.length ? "projetable" : "pas de machine à états"}
              </Card.Description>
              <Card.Description className="mt-sm">
                {g.resume.moments} moments · {g.resume.etats} états · {g.resume.transitions}{" "}
                transitions · {g.resume.extensions} extensions
              </Card.Description>
              <Card.Description>
                {g.resume.couvert}/{g.couverture.length} cas couverts
                {g.aArbitrer.length ? ` · ${g.aArbitrer.length} à arbitrer` : ""}
              </Card.Description>
            </Card.Body>
          </Card.Root>
        ))}
      </div>
    </main>
  );
}
