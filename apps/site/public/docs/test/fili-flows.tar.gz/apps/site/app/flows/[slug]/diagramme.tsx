"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Background,
  BackgroundVariant,
  Controls,
  MarkerType,
  ReactFlow,
  ReactFlowProvider,
  type Edge,
  type Node,
} from "@xyflow/react";
import ELK from "elkjs/lib/elk.bundled.js";
import "@xyflow/react/dist/style.css";
import type { Graphe } from "@/lib/flows";
import { typesDeNoeud } from "./noeuds";

const elk = new ELK();

const L_ETAT = 224;
const H_ETAT = 108;
const L_EXT = 248;
const H_EXT = 104;

/**
 * Le diagramme est une PROJECTION : tout ce qu'il montre vient de `content/flows/<slug>.json`,
 * lui-même dérivé de la fiche. Aucun nœud, aucune arête n'est écrit ici à la main — ce qui
 * n'est pas dans la fiche apparaît comme détaché, jamais comme deviné.
 */
export function Diagramme({ graphe }: { graphe: Graphe }) {
  const [noeuds, setNoeuds] = useState<Node[]>([]);
  const [aretes, setAretes] = useState<Edge[]>([]);

  const brut = useMemo(() => construis(graphe), [graphe]);

  useEffect(() => {
    let vivant = true;
    dispose(brut, graphe).then((n) => {
      if (vivant) {
        setNoeuds(n);
        setAretes(brut.aretes);
      }
    });
    return () => {
      vivant = false;
    };
  }, [brut, graphe]);

  return (
    <div className="h-[620px] w-full overflow-hidden rounded-lg border border-border bg-background">
      <ReactFlowProvider>
        <ReactFlow
          nodes={noeuds}
          edges={aretes}
          nodeTypes={typesDeNoeud}
          fitView
          fitViewOptions={{ padding: 0.15 }}
          proOptions={{ hideAttribution: false }}
          nodesDraggable={false}
          nodesConnectable={false}
          edgesFocusable={false}
          minZoom={0.3}
          maxZoom={1.6}
          aria-label={`Diagramme du parcours ${graphe.flow}`}
        >
          <Background variant={BackgroundVariant.Dots} gap={20} size={1} className="!bg-background" />
          <Controls showInteractive={false} />
        </ReactFlow>
      </ReactFlowProvider>
    </div>
  );
}

/* ------------------------------------------------------------------ montage */

type Brut = { noeuds: Node[]; aretes: Edge[] };

function construis(g: Graphe): Brut {
  const noeuds: Node[] = [];
  const aretes: Edge[] = [];

  const entrantVers = new Map(g.transitions.filter((t) => t.de).map((t) => [t.vers, t]));
  const idsBifurcation = new Set(g.bifurcations.map((b) => b.id));

  for (const etat of g.etats) {
    if (etat.sousEtats.length) {
      noeuds.push({
        id: etat.id,
        type: "groupe",
        position: { x: 0, y: 0 },
        data: { libelle: etat.libelle },
        style: { width: 0, height: 0 },
        selectable: false,
        draggable: false,
      });
      for (const sous of etat.sousEtats) {
        const t = entrantVers.get(sous.id);
        noeuds.push({
          id: sous.id,
          type: "etat",
          parentId: etat.id,
          extent: "parent",
          position: { x: 0, y: 0 },
          data: {
            libelle: sous.libelle,
            precision: null,
            entrant: t?.libelle ?? null,
            condition: t?.condition ?? null,
            focus: t?.focus ?? null,
            saisie: t?.saisie ?? null,
          },
        });
      }
    } else {
      const t = entrantVers.get(etat.id);
      noeuds.push({
        id: etat.id,
        type: "etat",
        position: { x: 0, y: 0 },
        data: {
          libelle: etat.libelle,
          precision: etat.precision,
          entrant: t?.libelle ?? null,
          condition: t?.condition ?? null,
          focus: t?.focus ?? null,
          saisie: t?.saisie ?? null,
        },
      });
    }
  }

  for (const b of g.bifurcations) {
    const t = g.transitions.find((tr) => tr.vers === b.id);
    noeuds.push({
      id: b.id,
      type: "bifurcation",
      position: { x: 0, y: 0 },
      data: { libelle: b.depuis, vers: b.vers, origineNommee: Boolean(t?.de) },
    });
  }

  for (const e of g.extensions) {
    noeuds.push({
      id: e.slug,
      type: "extension",
      position: { x: 0, y: 0 },
      data: { titre: e.titre, slug: e.slug, cas: e.couverture.length },
    });
  }

  for (const t of g.transitions) {
    if (!t.de) continue;
    aretes.push({
      id: `${t.de}--${t.vers}`,
      source: t.de,
      target: t.vers,
      label: t.condition ?? undefined,
      labelShowBg: true,
      markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
      style: { strokeWidth: 1.5 },
      animated: false,
    });
  }

  // Les nœuds détachés (bifurcations sans origine, extensions) restent SANS arête :
  // le trou de la fiche doit se voir, pas se combler.
  const connectes = new Set(aretes.flatMap((a) => [a.source, a.target]));
  for (const n of noeuds) {
    if (n.type === "groupe" || connectes.has(n.id)) continue;
    if (idsBifurcation.has(n.id) || n.type === "extension") n.data = { ...n.data, detache: true };
  }

  return { noeuds, aretes };
}

/* ------------------------------------------------------------- mise en place */

async function dispose(brut: Brut, g: Graphe): Promise<Node[]> {
  const connectes = new Set(brut.aretes.flatMap((a) => [a.source, a.target]));
  const dansLeGraphe = brut.noeuds.filter(
    (n) => n.type === "groupe" || connectes.has(n.id),
  );
  const detaches = brut.noeuds.filter(
    (n) => n.type !== "groupe" && !connectes.has(n.id),
  );

  const parGroupe = new Map<string, Node[]>();
  const racine: Node[] = [];
  for (const n of dansLeGraphe) {
    if (n.parentId) {
      if (!parGroupe.has(n.parentId)) parGroupe.set(n.parentId, []);
      parGroupe.get(n.parentId)!.push(n);
    } else racine.push(n);
  }

  const arbre = {
    id: "racine",
    layoutOptions: {
      "elk.algorithm": "layered",
      "elk.direction": "RIGHT",
      "elk.layered.spacing.nodeNodeBetweenLayers": "72",
      "elk.spacing.nodeNode": "36",
      "elk.padding": "[top=24,left=24,bottom=24,right=24]",
    },
    children: racine.map((n) => {
      const enfants = parGroupe.get(n.id);
      if (!enfants) return { id: n.id, width: L_ETAT, height: H_ETAT };
      return {
        id: n.id,
        layoutOptions: {
          "elk.algorithm": "layered",
          "elk.direction": "RIGHT",
          "elk.padding": "[top=32,left=16,bottom=16,right=16]",
          "elk.layered.spacing.nodeNodeBetweenLayers": "48",
        },
        children: enfants.map((e) => ({ id: e.id, width: L_ETAT, height: H_ETAT })),
        edges: brut.aretes
          .filter((a) => enfants.some((e) => e.id === a.source) && enfants.some((e) => e.id === a.target))
          .map((a) => ({ id: a.id, sources: [a.source], targets: [a.target] })),
      };
    }),
    edges: brut.aretes
      .filter((a) => {
        const s = brut.noeuds.find((n) => n.id === a.source);
        const t = brut.noeuds.find((n) => n.id === a.target);
        return !(s?.parentId && s.parentId === t?.parentId);
      })
      .map((a) => {
        const s = brut.noeuds.find((n) => n.id === a.source);
        const t = brut.noeuds.find((n) => n.id === a.target);
        return { id: a.id, sources: [s?.parentId ?? a.source], targets: [t?.parentId ?? a.target] };
      }),
  };

  let calcule: Record<string, { x: number; y: number; w: number; h: number }> = {};
  let basDuGraphe = 0;
  try {
    const res = await elk.layout(arbre as never);
    for (const enfant of (res.children ?? []) as never[]) {
      const c = enfant as { id: string; x: number; y: number; width: number; height: number; children?: never[] };
      calcule[c.id] = { x: c.x, y: c.y, w: c.width, h: c.height };
      basDuGraphe = Math.max(basDuGraphe, c.y + c.height);
      for (const petit of (c.children ?? []) as never[]) {
        const p = petit as { id: string; x: number; y: number; width: number; height: number };
        calcule[p.id] = { x: p.x, y: p.y, w: p.width, h: p.height };
      }
    }
  } catch {
    // Si elk échoue, une grille lisible plutôt qu'un canevas vide.
    dansLeGraphe.forEach((n, i) => {
      calcule[n.id] = { x: i * (L_ETAT + 72), y: 0, w: L_ETAT, h: H_ETAT };
    });
    basDuGraphe = H_ETAT;
  }

  const places: Node[] = dansLeGraphe.map((n) => {
    const c = calcule[n.id];
    return {
      ...n,
      position: { x: c?.x ?? 0, y: c?.y ?? 0 },
      style:
        n.type === "groupe"
          ? { width: c?.w ?? L_ETAT, height: c?.h ?? H_ETAT, zIndex: -1 }
          : n.style,
    };
  });

  // Bande des détachés, sous le parcours : leur absence de lien EST l'information.
  const yBande = basDuGraphe + 140;
  detaches.forEach((n, i) => {
    places.push({
      ...n,
      position: { x: i * (L_EXT + 32), y: yBande + (n.type === "bifurcation" ? 0 : H_EXT + 40) },
    });
  });

  void g;
  return places;
}
