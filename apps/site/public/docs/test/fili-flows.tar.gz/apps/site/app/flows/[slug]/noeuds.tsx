"use client";

import { Handle, Position, type NodeProps } from "@xyflow/react";
import { Card } from "@fili/react";

/**
 * Les nœuds du diagramme sont des `Card` du kit — pas une anatomie parallèle
 * (FILI-COMPONENT-CONTRACT § loi atomique : « si un composant existe, il doit être
 * réutilisé »). Cette page ne possède que la MISE EN PAGE ; le rendu interne du nœud
 * appartient à Card.
 *
 * Ce qui reste à React Flow : le canevas, les arêtes, les poignées, les contrôles.
 * C'est une dépendance de page, jamais une primitive du kit.
 */

const poignees = (
  <>
    <Handle type="target" position={Position.Left} className="!h-2 !w-2 !border-border !bg-surface" />
    <Handle type="source" position={Position.Right} className="!h-2 !w-2 !border-border !bg-surface" />
  </>
);

export type DonneesEtat = {
  libelle: string;
  precision: string | null;
  entrant: string | null;
  condition: string | null;
  focus: string | null;
  saisie: string | null;
};

/** Un état de la trajectoire du compte. */
export function NoeudEtat({ data, selected }: NodeProps) {
  const d = data as unknown as DonneesEtat;
  return (
    <div className="w-[224px]">
      {poignees}
      <Card.Root
        mode="static"
        density="compact"
        className={selected ? "!border-primary" : undefined}
      >
        <Card.Body>
          <Card.Title className="text-sm">{d.libelle}</Card.Title>
          {d.precision ? <Card.Description>{d.precision}</Card.Description> : null}
          {d.condition ? (
            <Card.Description className="mt-sm">
              <span className="font-label uppercase tracking-wider text-text-muted">
                condition de sortie
              </span>
              <br />
              {d.condition}
            </Card.Description>
          ) : null}
        </Card.Body>
      </Card.Root>
    </div>
  );
}

export type DonneesBifurcation = { libelle: string; vers: string; origineNommee: boolean };

/** Une sortie du parcours canonique : e-mail déjà utilisé, abandon. */
export function NoeudBifurcation({ data }: NodeProps) {
  const d = data as unknown as DonneesBifurcation;
  return (
    <div className="w-[224px]">
      {poignees}
      <Card.Root mode="static" density="compact" className="border-dashed">
        <Card.Body>
          <Card.Title className="text-sm">{d.libelle}</Card.Title>
          <Card.Description>→ {d.vers}</Card.Description>
          {d.origineNommee ? null : (
            <Card.Description className="mt-sm text-text-muted">
              origine non nommée dans la fiche
            </Card.Description>
          )}
        </Card.Body>
      </Card.Root>
    </div>
  );
}

export type DonneesExtension = { titre: string; slug: string; cas: number };

/** Une extension de la fiche — affichée détachée tant que son rattachement n'est pas écrit. */
export function NoeudExtension({ data }: NodeProps) {
  const d = data as unknown as DonneesExtension;
  return (
    <div className="w-[248px]">
      {poignees}
      <Card.Root mode="static" density="compact">
        <Card.Body>
          <Card.Title className="text-sm">{d.titre}</Card.Title>
          <Card.Description className="font-mono text-xs">{d.slug}</Card.Description>
          <Card.Description className="mt-sm">
            {d.cas} cas d’usage rattachés par l’inventaire
          </Card.Description>
        </Card.Body>
      </Card.Root>
    </div>
  );
}

/** Le cadre d'un état composite (« en cours ») — pure mise en page, aucun contenu. */
export function NoeudGroupe({ data }: NodeProps) {
  const d = data as unknown as { libelle: string };
  return (
    <div className="h-full w-full rounded-lg border border-dashed border-border bg-surface/40">
      <span className="absolute left-sm top-1 font-label text-xs uppercase tracking-wider text-text-muted">
        {d.libelle}
      </span>
    </div>
  );
}

export const typesDeNoeud = {
  etat: NoeudEtat,
  bifurcation: NoeudBifurcation,
  extension: NoeudExtension,
  groupe: NoeudGroupe,
};
