import { Card } from "@fili/react";
import { diagrammable, tousLesGraphes } from "@/lib/flows";

export default function PageFlows() {
  const graphes = tousLesGraphes();

  return (
    <main className="mx-auto max-w-[1200px] px-lg py-xl">
      <header className="mb-xl max-w-[70ch]">
        <p className="m-0 font-label text-xs font-semibold uppercase tracking-wider text-text-muted">
          Flows
        </p>
        <h1 className="m-0 mt-1 text-h2 font-semibold text-text-primary">
          Les parcours, vus comme des diagrammes
        </h1>
        <p className="mt-sm text-text-secondary">
          Chaque vue est une projection de sa fiche <code className="font-mono text-sm">-UX.md</code>,
          pas un dessin. Un parcours n’apparaît en graphe que si sa fiche porte une machine à états.
        </p>
      </header>

      <div className="grid gap-md md:grid-cols-2">
        {graphes.map((g) => (
          <Card.Root key={g.flow} mode="clickable">
            <Card.Body>
              <Card.Title className="text-sm">
                <Card.TitleLink href={`/flows/${g.flow}/`}>{g.flow}</Card.TitleLink>
              </Card.Title>
              <Card.Description className="font-label text-xs uppercase tracking-wider text-text-muted">
                v{g.version} · {diagrammable(g) ? "projetable" : "pas de machine à états"}
              </Card.Description>
              <Card.Description className="mt-sm">
                {g.resume.moments} moments · {g.resume.etats} états · {g.resume.transitions} transitions
                · {g.resume.extensions} extensions
              </Card.Description>
              <Card.Description>
                {g.resume.couvert}/{g.couverture.length} cas couverts
                {g.aArbitrer.length ? ` · ${g.aArbitrer.length} à arbitrer` : ""}
              </Card.Description>
            </Card.Body>
          </Card.Root>
        ))}
      </div>
    </main>
  );
}
